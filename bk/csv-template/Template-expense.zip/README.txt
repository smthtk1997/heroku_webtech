*** Type Field input ***
true = income
false = expense